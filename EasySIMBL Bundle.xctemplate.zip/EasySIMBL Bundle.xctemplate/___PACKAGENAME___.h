//
//  ___PACKAGENAME___.h
//  ___PACKAGENAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import <Foundation/Foundation.h>

@interface ___PACKAGENAME___ : NSObject

+ (instancetype)sharedInstance;

@end
